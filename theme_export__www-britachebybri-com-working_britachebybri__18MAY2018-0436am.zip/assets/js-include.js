//----- NOTE - if you use an apostrophe, it will need to be escaped like this: \' -----//

// Content variables
var mainTitle = ' ';
var contentLineOne = ' ';
var contentLineTwo = '  <a class="herbalife-close" href="#" onclick="wcHidePopUp()">ENTER</a>';  
var contentSmallPrint = ' ';  

// Image variables
var imageSteps = ' ';
var imageLogo = ' ';


// Popup HTML
varHTML = '<style>     </style><div class="herbalife-popup" id="wc_herba_popup"> <div class="herbalife-wrap"><div class="herbalife-content"><div class="herbalife-info"> <h1>'+ mainTitle +'</h1><div class="herbalife-row"> <div class="contents"><p>'+ contentLineOne +'</p><p>'+ contentLineTwo +'</p></div><div class="clear">&nbsp;</div></div> </div></div></div>';

// Write HTML
document.getElementById('herbalifepopup').innerHTML = varHTML;

// Set a cookie
function wcSetCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

// Get a cookie
function wcGetCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
}

// Hide popup
function wcHidePopUp () {
    document.getElementById('wc_herba_popup').style.display = 'none'; // or 'block', or whatever.
}

var cookie_content = wcGetCookie('wc_popup_herba');

if (cookie_content != "shown") {
    console.log('unset');
    document.getElementById('wc_herba_popup').style.display = 'block'; // or 'block', or whatever.
    wcSetCookie('wc_popup_herba', 'shown');
}